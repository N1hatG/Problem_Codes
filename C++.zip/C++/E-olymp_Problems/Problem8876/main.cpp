#include <iostream>
using namespace std;
int main ( )
{
    float a;
    cin>>a;
    if(a==(int)a)
        cout<<"Ok"<<endl;
    else
        cout<<"No"<<endl;
}
