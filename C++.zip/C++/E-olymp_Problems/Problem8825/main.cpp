#include <iostream>
#include <stdio.h>
using namespace std;
int main ( )
{
    float x,y;
    cin>>x;
    y=x*x*x-((5*x*x)/7)+9*x-(3/x)+1;
    printf("%.3f\n",y);
}
