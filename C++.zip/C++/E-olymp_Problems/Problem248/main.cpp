//
//  main.cpp
//  Problems248
//
//  Created by Nihat Guliyev on 13.04.22.
//

#include <iostream>

using namespace std;

int main()
{
    int n,res,sum;
    cin>>n;
    sum=(n*(n+1))/2;
    res=sum*2+1;
    cout<<res<<endl;
}
