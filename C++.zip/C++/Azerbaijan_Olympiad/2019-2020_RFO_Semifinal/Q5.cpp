#include <iostream>
#include <algorithm>
using namespace std;
int main ()
{
long long n,i,j,s=0,s1=0;
cin>>n;
long long m[2][2*n];
for(i=0;i<2;i++)
for(j=0;j<2*n;j++)
cin>>m[i][j];
for(i=0;i<2;i++)
for(j=0;j<2*n;j++)
{
if
}
}
