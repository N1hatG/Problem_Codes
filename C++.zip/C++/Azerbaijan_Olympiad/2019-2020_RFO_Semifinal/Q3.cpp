#include <iostream>
using namespace std;
int main()
{
long int a,b,k;
cin>>a>>b;
if((a+b)%2==0)
cout<<(a+b)/2<<endl;
else
cout<<"-"<<endl;
return 0;
}
